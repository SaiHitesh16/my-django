from django.db import models

# Create your models here.
class student(models.Model):
	name=models.CharField(max_length=20)
	roll=models.CharField(max_length=10)
	age=models.IntegerField(null=True)
	phone=models.CharField(max_length=10)
	email=models.EmailField(null=True)
	dob=models.DateField(null=True)

	def __str__(self):
		return self.name+" "+str(self.age)
class Addstudent(models.Model):
	name=models.CharField(max_length=20)
	roll=models.CharField(max_length=10)
	phone=models.CharField(max_length=10)
	email=models.EmailField(null=True)
	dob=models.DateField(null=True)
	def __str__(self):
		return self.name
class SR(models.Model):
	gender_vals=[('Male','Male'),('FeMale','FeMale'),('Other','Other')]
	Name=models.CharField(max_length=20)
	emailId=models.EmailField(null=True)
	phoneNo=models.CharField(max_length=10)
	age=models.IntegerField(null=True)
	gender=models.CharField(max_length=10,choices=gender_vals)
	def __str__(self):
		return self.Name  
class FR(models.Model):
	gender_vals=[('Male','Male'),('FeMale','FeMale'),('Other','Other')]
	Name=models.CharField(max_length=20)
	emailId=models.EmailField(null=True)
	phoneNo=models.CharField(max_length=10)
	age=models.IntegerField(null=True)
	gender=models.CharField(max_length=10,choices=gender_vals)
	date_of_birth=models.DateField(null=True)
	def __str__(self):
		return self.Name



from django.shortcuts import render,redirect
from django.http import HttpResponse
import datetime as dt
from demo.models import student,Addstudent,FR,SR 
from demo.forms import FRF,SRF 

# Create your views here.
def hi(response):
	return HttpResponse("Hi all")
def hello(response):
	return HttpResponse("Hello all")
def clgname(response):
	return HttpResponse("pscmr college")
def branch(response):
	return HttpResponse("cse")
def hey(response,name):
	return HttpResponse("hi {}".format(name))
def roll(response,id,marks):
	return HttpResponse("rollno: {} and marks:{}".format(id,marks))
def emp(response,name,age,salary,year):
	return HttpResponse("employee name:{}<br> employee age:{}<br> employee salary: {}<br> joining year:{}".format(name,age,salary,year))
def student(response,name,age,gender,dep):
	return HttpResponse('<p style="color:red;">student name: {}</p><br><p style="color:blue;">age: {}</p><br><p style="color:violet;">gender: {}</p><br><p style="color:pink;">branch: {}</p>'.format(name,age,gender,dep))
def welcome(request):
	return render(request,'a.html')
def myhtml(request):
	return render(request,'b.html')
def form(request):
	return render(request,'form.html')
def image(request):
	return render(request,'image.html')
def js(request):
	return render(request,'js.html')
def css(request):
	return render(request,'css.html')
def data(request):
	d=dt.datetime.now()
	return render(request,'data.html',{'D':d})
def register(request):
	if request.method=="POST":
		f=request.POST['firstname']
		m=request.POST['middlename']
		l=request.POST['lastname']
		c=request.POST['course']
		g=request.POST['Gender']
		p=request.POST['phone']
		a=request.POST['address']
		return HttpResponse("<center><h1>Data from registration page <br> {} <br> {} <br> {} <br> {} <br> {} <br> {} <br> {}".format(f,m,l,c,g,p,a))
	return render(request,'register.html')
def agec(request):
	if request.method=="POST":
		a=request.POST['age']
		return HttpResponse("{}".format(a))
	return render(request,'success.html')
def reg(request):
	if request.method=="POST":
		n=request.POST['name']
		d=request.POST['date']
		c=tuple(map(int,d.split("-")))
		bd=dt.date(c[0],c[1],c[2])
		n1=dt.date.today()
		age=n1.year-bd.year-((n1.month,n1.day)<(bd.month,bd.day))
		if age>=18:
			return HttpResponse("<center><h1>{}<br>{}<br>{}<br>Registration successful</h1></center>".format(n,d,age))

	return render(request,'reg.html')
def addstudent(request):
	if request.method=="POST":
		n=request.POST['name']
		r=request.POST['rollno']
		m=request.POST['phone']
		e=request.POST['email']
		d=request.POST['dob']
		Addstudent.objects.create(name=n,roll=r,phone=m,email=e,dob=d)
		return HttpResponse("{}<br>{}<br>{}<br>{}<br>{}".format(n,r,m,e,d))
	return render(request,'addstudent.html')
def display(request):
	data=Addstudent.objects.all()
	return render(request,"display.html",{'Data':data})
def sr(request):
	form = SRF(request.POST)
	if form.is_valid():
		student = SR(Name=request.POST.get('Name'),emailId=request.POST.get('emailId'),phoneNo=request.POST.get('phoneNo'),age=request.POST.get('age'),gender=request.POST.get('gender'))
		student.save()
		return HttpResponse('Student added')
	return render(request,'sr.html',{'form':form})
def fr(request):
	form = FRF(request.POST)
	if request.method == "POST":
		if form.is_valid():
			form.save()
			return HttpResponse('faculty_register done')
	return render(request,'fr.html',{'form':form})
def edit(request,id):
	ed=Addstudent.objects.get(id=id)
	if request.method == "POST":
		ed.name=request.POST.get('name')
		ed.roll=request.POST.get('rollno')
		ed.phone=request.POST.get('phone')
		ed.email=request.POST.get('email')
		ed.dob=request.POST.get('dob')
		ed.save()
		return redirect('display')
		#update=Addstudent(name=n,roll=r,phone=m,email=e,dob=d)
		#return HttpResponse("details edited succesfully:)")
	return render(request,'edit.html',{'ed':ed})

def delete(request,id):
	d=Addstudent.objects.get(id=id)
	d.delete()
	return redirect('display')
		#update=Addstudent(name=n,roll=r,phone=m,email=e,dob=d)
		#return HttpResponse("details edited succesfully:)")
	#return render(request,'delete.html',{'d':d})


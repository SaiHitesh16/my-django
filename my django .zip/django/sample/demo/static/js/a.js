alert("welcome all")
confirm("Are you sure to cancel")
prompt("hai")
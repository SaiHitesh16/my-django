from django.contrib import admin
from demo.models import student
admin.site.register(student)
# Register your models here.


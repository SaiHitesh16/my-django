"""sample URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include 
from demo import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as v
urlpatterns = [
    path('admin/', admin.site.urls),
    path('demo/',include('demo.urls')),
    path('hi/',views.hi),
    path('clgname/',views.clgname),
    path('hello/<str:name>/',views.hey),
    path('rollno/<int:id>/<int:marks>/',views.roll),
    path('employee/<str:name>/<int:age>/<int:salary>/<int:year>/',views.emp),
    path('student/<str:name>/<int:age>/<str:gender>/<str:dep>/',views.student),
    path('welcome/',views.welcome),
    path('myhtml/',views.myhtml),
    path('form/',views.form),
    path('image/',views.image),
    path('js/',views.js),
    path('css/',views.css),
    path('data/',views.data,name="data"),
    path('register/',views.register,name="register"),
    path('age/',views.agec),
    path('reg/',views.reg),
    path('addstudent/',views.addstudent,name="addstudent"),
    path('display/',views.display,name="display"),
    path('sr/',views.sr,name='sr'),
    path('fr/',views.fr,name='fr'),
    path('edit/<int:id>/',views.edit,name="edit"),
    path('delete/<int:id>/',views.delete,name="delete"),
    path('login/',v.LoginView.as_view(template_name="login.html"),name="login"),
    path('lgo/',v.LogoutView.as_view(template_name="logout.html"),name="lgo"),

]
